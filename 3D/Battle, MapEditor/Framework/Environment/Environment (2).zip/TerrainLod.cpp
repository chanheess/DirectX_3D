#include "Framework.h"
#include "TerrainLod.h"

TerrainLod::TerrainLod(InitializeDesc & desc, bool modify)
	: Renderer(desc.shader), initDesc(desc), modify(modify)
{
	Topology(D3D11_PRIMITIVE_TOPOLOGY_4_CONTROL_POINT_PATCHLIST);

	sBaseMap = shader->AsSRV("BaseMap");

	map[0].sLayerMap = shader->AsSRV("LayerMap");
	map[0].sAlphaMap = shader->AsSRV("AlphaMap");
	map[1].sLayerMap = shader->AsSRV("LayerMap1");
	map[1].sAlphaMap = shader->AsSRV("AlphaMap1");
	map[2].sLayerMap = shader->AsSRV("LayerMap2");
	map[2].sAlphaMap = shader->AsSRV("AlphaMap2");
	map[3].sLayerMap = shader->AsSRV("LayerMap3");
	map[3].sAlphaMap = shader->AsSRV("AlphaMap3");

	sHeightMap = shader->AsSRV("HeightMap");
	sNormalMap = shader->AsSRV("NormalMap");

	buffer = new ConstantBuffer(&bufferDesc, sizeof(BufferDesc));
	sBuffer = shader->AsConstantBuffer("CB_TerrainLod");

	brushBuffer = new ConstantBuffer(&brushDesc, sizeof(BrushDesc));
	sBrushBuffer = shader->AsConstantBuffer("CB_Brush");


	heightMap = new Texture(initDesc.heightMap);
	sHeightMap->SetResource(heightMap->SRV());
	heightColors = new float[heightMap->GetWidth() * heightMap->GetHeight()];
	heightMap->ReadPixel(DXGI_FORMAT_R32_FLOAT, heightColors);

	heightMap->CreateWritingTexture(DXGI_FORMAT_R32_FLOAT);
	heightMap->CreateSRVTexture(DXGI_FORMAT_R32_FLOAT);


	width = this->heightMap->GetWidth();
	height = this->heightMap->GetHeight();


	vertexPerPatchX = (width / initDesc.CellsPerPatch) + 1;
	vertexPerPatchZ = (height / initDesc.CellsPerPatch) + 1;

	vertexCount = vertexPerPatchX * vertexPerPatchZ;
	faceCount = (vertexPerPatchX - 1) * (vertexPerPatchZ - 1);
	indexCount = faceCount * 4;


	CalcBoundY();
	CreateVertexData();
	CreateIndexData();

	vertexBuffer = new VertexBuffer(vertices, vertexCount, sizeof(VertexTerrain));	//
	indexBuffer = new IndexBuffer(indices, indexCount);

	bufferDesc.TexelCellSpaceU = 1.0f / (float)heightMap->GetWidth() - 1;
	bufferDesc.TexelCellSpaceV = 1.0f / (float)heightMap->GetHeight() - 1;
	bufferDesc.HeightRatio = initDesc.HeightRatio;

	camera = new Fixity();
	perspective = new Perspective(D3D::Width(), D3D::Height(), 0.1f, 1000.0f, Math::PI * 0.35f);

	frustum = new Frustum(NULL, perspective);
	//frustum = new Frustum(camera, perspective);
}

TerrainLod::~TerrainLod()
{
	SafeDeleteArray(vertices);
	SafeDeleteArray(indices);

	SafeDelete(brushBuffer);
	SafeDelete(buffer);
	SafeDelete(frustum);
	SafeDelete(camera);
	SafeDelete(perspective);

	SafeDelete(heightMap);

	SafeDelete(baseMap);

	for (UINT i = 0; i < 4; i++)
	{
		SafeDelete(map[i].layerMap);
		SafeDelete(map[i].alphaMap);
	}
}

void TerrainLod::Update()
{
	Super::Update();

	camera->Update();

	frustum->Update();
	frustum->Planes(bufferDesc.WorldFrustumPlanes);

	if (modify == false) return;
	//====================================================================

	ImGui::SliderFloat("MinDistance", &bufferDesc.MinDistance, 1, 100);
	ImGui::SliderFloat("MaxDistance", &bufferDesc.MaxDistance, 1, 1000);

	//MousePos
	if (Mouse::Get()->Press(0))
	{
		Vector3 pos = GetPickedPosition();
		pos.y = GetHeight(pos);
		pos.x = pos.x + width * 0.5f;
		pos.z = pos.z + height * 0.5f;
		ImGui::InputFloat3("currPos", pos);
	}

	//Brush
	{
		static bool brushOn = false;
		ImGui::Checkbox("Brush", &brushOn);
		if (brushOn == true)
		{
			ImGui::Begin("BrushEditor");
			{
				static float heightPower = 5.0f;

ImGui::InputInt("BrushType", (int *)&brushDesc.Type);
brushDesc.Type %= 3;

ImGui::InputInt("HeightType", (int *)&brushDesc.HeightType);
brushDesc.HeightType %= 3;

if (heightPower <= 50.0f)
ImGui::InputFloat("HeightPower", &heightPower, 0.1f);
if (heightPower > 50.0f)
heightPower = 50.0f;
if (heightPower < 0.0f)
	heightPower = 0.0f;

ImGui::InputInt("Range", (int *)&brushDesc.Range);
brushDesc.Range %= 51;

if (brushDesc.HeightType == 2)
ImGui::InputInt("Range2", (int *)&brushDesc.Range2);
brushDesc.Range2 %= 26;

if (brushDesc.Type > 0)
{
	static bool clickOn = false;
	ImGui::Checkbox("== ClickOn/Off : P ==", &clickOn);
	if (Keyboard::Get()->Down('P'))
	{
		if (clickOn == true)
			clickOn = false;
		else if (clickOn == false)
			clickOn = true;
	}
	//���콺�� ��ġ
	brushDesc.Location = GetPickedPosition();

	if (brushDesc.Type == 1)
		ImGui::Text("== Square ==");
	else if (brushDesc.Type == 2)
		ImGui::Text("== Circle ==");

	switch (brushDesc.HeightType)
	{
	case 0:	//�⺻ �ø���
		ImGui::Text("== Height ==");
		ImGui::Text("== 'Shift' : Up/Down ==");

		if (Mouse::Get()->Press(0) && clickOn == true)
			RaiseHeight(brushDesc.Location, brushDesc.Type, brushDesc.Range, heightPower);
		break;

	case 1:	//��źȭ
		ImGui::Text("== Flatten ==");
		ImGui::Text("== 'Shift' : Curr/Power ==");

		if (Mouse::Get()->Press(0) && clickOn == true)
			MiddleHeight(brushDesc.Location, brushDesc.Type, brushDesc.Range, fixed, heightPower);
		else
			fixed = false;
		break;

	case 2:		//����
		ImGui::Text("== Slope ==");
		ImGui::Text("== 'Shift' : Up/Down ==");
		ImGui::Text("== Range : X, Range2 : Y ==");
		ImGui::Text("== Input Direction ==");

		if (brushDesc.Type == 2) brushDesc.Type = 1;

		//���� �Է�
		{
			if (Keyboard::Get()->Down(VK_LEFT))
				brushDesc.SlopeDirection = 0;
			if (Keyboard::Get()->Down(VK_RIGHT))
				brushDesc.SlopeDirection = 1;
			if (Keyboard::Get()->Down(VK_UP))
				brushDesc.SlopeDirection = 2;
			if (Keyboard::Get()->Down(VK_DOWN))
				brushDesc.SlopeDirection = 3;
		}

		if (Mouse::Get()->Press(0) && clickOn == true)
			SlopeHeight(brushDesc.Location, brushDesc.Type, brushDesc.Range, brushDesc.Range2, brushDesc.SlopeDirection, heightPower);
		break;

		//case 3:	//������
		//	ImGui::Text("== SmoothHeight ==");
		//	ImGui::Text("== 'Shift' : Up/Down ==");

		//	//if (Mouse::Get()->Press(0) && clickOn == true)
		//	//	RaiseHeight(brushDesc.Location, brushDesc.Type, brushDesc.HeightType, brushDesc.Range, heightPower);
		//	break;

	}//switch

}
			}
			ImGui::End();
		}
	}

	//Splatting
	{
		Splatting();
	}
}

void TerrainLod::Render()
{
	Super::Render();

	if (baseMap != NULL)
		sBaseMap->SetResource(baseMap->SRV());

	for (UINT i = 0; i < 4; i++)
	{
		if (map[i].layerMap != NULL)
			map[i].sLayerMap->SetResource(map[i].layerMap->SRV());

		if (map[i].alphaMap != NULL)
			map[i].sAlphaMap->SetResource(map[i].alphaMap->SRV());
	}

	if (normalMap != NULL)
		sNormalMap->SetResource(normalMap->SRV());


	buffer->Apply();
	sBuffer->SetConstantBuffer(buffer->Buffer());
	brushBuffer->Apply();
	sBrushBuffer->SetConstantBuffer(brushBuffer->Buffer());
	shader->DrawIndexed(0, Pass(), indexCount);

}

void TerrainLod::BaseMap(wstring file)
{
	SafeDelete(baseMap);

	baseMap = new Texture(file);
}

void TerrainLod::LayerMap(wstring layer, wstring alpha)
{
	SafeDelete(map[0].alphaMap);
	SafeDelete(map[0].layerMap);

	map[0].alphaMap = new Texture(alpha);
	map[0].layerMap = new Texture(layer);
}

void TerrainLod::LayerMap1(wstring layer, wstring alpha)
{
	SafeDelete(map[1].alphaMap);
	SafeDelete(map[1].layerMap);

	map[1].alphaMap = new Texture(alpha);
	map[1].layerMap = new Texture(layer);
}

void TerrainLod::LayerMap2(wstring layer, wstring alpha)
{
	SafeDelete(map[2].alphaMap);
	SafeDelete(map[2].layerMap);

	map[2].alphaMap = new Texture(alpha);
	map[2].layerMap = new Texture(layer);
}

void TerrainLod::LayerMap3(wstring layer, wstring alpha)
{
	SafeDelete(map[3].alphaMap);
	SafeDelete(map[3].layerMap);

	map[3].alphaMap = new Texture(alpha);
	map[3].layerMap = new Texture(layer);
}

void TerrainLod::NormalMap(wstring file)
{
	SafeDelete(normalMap);

	normalMap = new Texture(file);
}

Vector3 TerrainLod::GetPickedPosition()
{
	Matrix V = Context::Get()->View();
	Matrix P = Context::Get()->Projection();
	Viewport* Vp = Context::Get()->GetViewport();

	Vector3 mouse = Mouse::Get()->GetPosition();


	Vector3 n, f;
	mouse.z = 0.0f;
	Vp->Unproject(&n, mouse, transform->World(), V, P);

	mouse.z = 1.0f;
	Vp->Unproject(&f, mouse, transform->World(), V, P);

	Vector3 start = n;
	Vector3 direction = f - n;

	for (UINT z = 0; z < height - 1; z++)
	{
		for (UINT x = 0; x < width - 1; x++)
		{
			UINT index[4];
			index[0] = width * z + x;
			index[1] = width * (z + 1) + x;
			index[2] = width * z + x + 1;
			index[3] = width * (z + 1) + x + 1;

			Vector3 p[4];
			for (int i = 0; i < 4; i++)
				p[i] = vertices[index[i]].Position;


			float u, v, distance;
			if (D3DXIntersectTri(&p[0], &p[1], &p[2], &start, &direction, &u, &v, &distance) == TRUE)
				return p[0] + (p[1] - p[0]) * u + (p[2] - p[0]) * v;
			if (D3DXIntersectTri(&p[3], &p[1], &p[2], &start, &direction, &u, &v, &distance) == TRUE)
				return p[3] + (p[1] - p[3]) * u + (p[2] - p[3]) * v;
		}
	}

	return Vector3(-1, FLT_MIN, -1);
}

float TerrainLod::GetHeight(Vector3 & position)
{
	UINT x = (int)position.x + (width * 0.5f);
	UINT z = (int)position.z + (height * 0.5f);

	if (x < 0 || x > width) return FLT_MIN;
	if (z < 0 || z > height) return FLT_MIN;

	UINT pixel = width * (height - z) + x;

	return heightColors[pixel] * 255.0f / bufferDesc.HeightRatio;
}

bool TerrainLod::InBounds(UINT x, UINT z)
{
	return x >= 0 && x < width && z >= 0 && z < height;
}

void TerrainLod::CalcPatchBounds(UINT x, UINT z)
{
	UINT x0 = x * initDesc.CellsPerPatch;
	UINT x1 = (x + 1) * initDesc.CellsPerPatch;

	UINT z0 = z * initDesc.CellsPerPatch;
	UINT z1 = (z + 1) * initDesc.CellsPerPatch;


	float minY = FLT_MAX;
	float maxY = FLT_MIN;

	for (UINT z = z0; z <= z1; z++)
	{
		for (UINT x = x0; x <= x1; x++)
		{
			float y = 0.0f;
			UINT pixel = width * (height - 1 - z) + x;

			if (InBounds(x, z))
				y = heightColors[pixel] * 255 / initDesc.HeightRatio;

			minY = min(minY, y);
			maxY = max(maxY, y);
		}
	}

	UINT patchID = (vertexPerPatchX - 1) * z + x;
	bounds[patchID] = Vector2(minY, maxY);
}

void TerrainLod::CalcBoundY()
{
	bounds.assign(faceCount, Vector2());

	for (UINT z = 0; z < vertexPerPatchZ - 1; z++)
	{
		for (UINT x = 0; x < vertexPerPatchX - 1; x++)
		{
			CalcPatchBounds(x, z);
		}
	}
}

void TerrainLod::CreateVertexData()
{
	vertices = new VertexTerrain[vertexCount];

	float halfWidth = (float)width * 0.5f;
	float halfHeight = (float)height * 0.5f;

	float patchWidth = (float)width / (float)(vertexPerPatchX - 1);
	float patchHeight = (float)height / (float)(vertexPerPatchZ - 1);

	float u = 1.0f / (float)(vertexPerPatchX - 1);
	float v = 1.0f / (float)(vertexPerPatchZ - 1);
	//float id = 0;
	for (UINT z = 0; z < vertexPerPatchZ; z++)
	{
		float z1 = halfHeight - (float)z * patchHeight;

		for (UINT x = 0; x < vertexPerPatchX; x++)
		{
			float x1 = -halfWidth + (float)x * patchWidth;
			UINT patchId = vertexPerPatchX * z + x;

			vertices[patchId].Position = Vector3(x1, 0, z1);
			vertices[patchId].Uv = Vector2(x * u, z * v);
			//vertices[patchId].ID = Vector3(id, 0, 0);
			//id += 0.001f;
		}
	}

	for (UINT z = 0; z < vertexPerPatchZ - 1; z++)
	{
		for (UINT x = 0; x < vertexPerPatchX - 1; x++)
		{
			UINT patchID = (vertexPerPatchX - 1) * z + x;
			UINT vertID = vertexPerPatchX * z + x;

			vertices[vertID].BoundsY = bounds[patchID];
		}
	}
}

void TerrainLod::CreateIndexData()
{
	UINT index = 0;
	this->indices = new UINT[indexCount];
	for (UINT z = 0; z < vertexPerPatchZ - 1; z++)
	{
		for (UINT x = 0; x < vertexPerPatchX - 1; x++)
		{
			this->indices[index++] = vertexPerPatchX * z + x;
			this->indices[index++] = vertexPerPatchX * z + x + 1;
			this->indices[index++] = vertexPerPatchX * (z + 1) + x;
			this->indices[index++] = vertexPerPatchX * (z + 1) + x + 1;
		}
	}
}

void TerrainLod::RaiseHeight(Vector3 &position, UINT type, UINT range, float power)
{
	UINT x = (int)position.x + (width * 0.5f);
	UINT z = (int)position.z + (height * 0.5f);

	D3D11_RECT rect;
	rect.left = x - range;
	rect.top = z + range;
	rect.right = x + range;
	rect.bottom = z - range;

	if (rect.left < 0) rect.left = 0;
	if (rect.top >= (LONG)height) rect.top = (LONG)height;
	if (rect.right >= (LONG)width) rect.right = (LONG)width;
	if (rect.bottom < 0) rect.bottom = 0;
	
	for (LONG zi = rect.bottom; zi <= rect.top; zi++)
	{
		for (LONG xi = rect.left; xi <= rect.right; xi++)
		{
			UINT index = width * (height - (UINT)zi) + (UINT)xi;


			switch (type)
			{
			case 1:
				if (Keyboard::Get()->Press(VK_LSHIFT))
					heightColors[index] -= power / 255.0f * initDesc.HeightRatio * Time::Get()->Delta();
				else
					heightColors[index] += power / 255.0f * initDesc.HeightRatio * Time::Get()->Delta();
				break;
			case 2:
				float dxi = x;
				float dzi = z;

				float dx = (float)xi - dxi;
				float dz = (float)zi - dzi;
				float dist = sqrt(dx * dx + dz * dz);

				if (dist <= (float)range)
				{
					float ratio = dist / range;
					float theta = (Math::PI / 2.0f) * ratio;
					float forceValue = cos(theta);

					if (Keyboard::Get()->Press(VK_LSHIFT))
						heightColors[index] -= (forceValue / 2.0f) * power / 255.0f * initDesc.HeightRatio * Time::Get()->Delta();
					else
						heightColors[index] += (forceValue / 2.0f) * power / 255.0f * initDesc.HeightRatio * Time::Get()->Delta();
				}
				break;
			}

		}//for
	}//for

	TextureApply();
}

void TerrainLod::MiddleHeight(Vector3 &position, UINT type, UINT range, bool &fixed, float power)
{
	UINT x = (int)position.x + (width * 0.5f);
	UINT z = (int)position.z + (height * 0.5f);

	D3D11_RECT rect;
	rect.left = x - range;
	rect.top = z + range;
	rect.right = x + range;
	rect.bottom = z - range;


	// terrain�� ���ʿ��� ������ �� �̻��� ������ �����ȵǰ�
	if (rect.left < 0) rect.left = 0;
	if (rect.top >= (LONG)height) rect.top = (LONG)height;
	if (rect.right >= (LONG)width) rect.right = (LONG)width;
	if (rect.bottom < 0) rect.bottom = 0;


	for (LONG zi = rect.bottom; zi <= rect.top; zi++)
	{
		for (LONG xi = rect.left; xi <= rect.right; xi++)
		{
			UINT index = width * (height - (UINT)zi) + (UINT)xi;

			switch (type)
			{
			case 1:
				if (Keyboard::Get()->Press(VK_LSHIFT))
				{
					static float pixedY = 0.0f;

					if (fixed == false)
					{
						pixedY = GetHeight(position);
						fixed = true;
					}

					heightColors[index] = pixedY / 255.0f * initDesc.HeightRatio;
				}
				else
				{
					heightColors[index] = power / 255.0f * initDesc.HeightRatio;
				}
				break;
			case 2:
				float dxi = x;
				float dzi = z;

				float dx = (float)xi - dxi;
				float dz = (float)zi - dzi;
				float dist = sqrt(dx * dx + dz * dz);

				if (dist <= (float)range)
				{
					if (Keyboard::Get()->Press(VK_LSHIFT))
					{
						static float pixedY = 0.0f;

						if (fixed == false)
						{
							pixedY = GetHeight(position);
							fixed = true;
						}

						heightColors[index] = pixedY / 255.0f * initDesc.HeightRatio;
					}
					else
					{
						heightColors[index] = power / 255.0f * initDesc.HeightRatio;
					}
				}
				break;
			}
		}
	}

	TextureApply();
}

void TerrainLod::SlopeHeight(Vector3 & position, UINT type, UINT range, UINT range2, UINT direction, float power)
{
	UINT x = (int)position.x + (width * 0.5f);
	UINT z = (int)position.z + (height * 0.5f);

	D3D11_RECT rect;

	switch (direction)
	{
	case 0:	//L
		rect.left = x - range;
		rect.top = z + range2;
		rect.right = x;
		rect.bottom = z - range2;
		break;
	case 1:	//R
		rect.left = x;
		rect.top = z + range2;
		rect.right = x + range;
		rect.bottom = z - range2;
		break;
	case 2:	//U
		rect.left = x - range2;
		rect.top = z + range;
		rect.right = x + range2;
		rect.bottom = z;
		break;
	case 3:	//D
		rect.left = x - range2;
		rect.top = z;
		rect.right = x + range2;
		rect.bottom = z - range;
		break;
	}

	// terrain�� ���ʿ��� ������ �� �̻��� ������ �����ȵǰ�
	if (rect.left < 0) rect.left = 0;
	if (rect.top >= (LONG)height) rect.top = (LONG)height;
	if (rect.right >= (LONG)width) rect.right = (LONG)width;
	if (rect.bottom < 0) rect.bottom = 0;

	for (LONG zi = rect.bottom; zi <= rect.top; zi++)
	{
		for (LONG xi = rect.left; xi <= rect.right; xi++)
		{
			UINT index = width * (height - (UINT)zi) + (UINT)xi;

			if (direction == 0 || direction == 1)
			{
				float dxi = x;
				float dx = (float)xi - dxi;
				float dy = (heightColors[index] * 255.0f / initDesc.HeightRatio) - GetHeight(position);
				float dist = sqrt(dx * dx + dy * dy);

				if (Mouse::Get()->Press(0))
				{
					if (Keyboard::Get()->Press(VK_LSHIFT))
						heightColors[index] -= power * dist / 255.0f * initDesc.HeightRatio * Time::Get()->Delta();
					else
						heightColors[index] += power * dist / 255.0f * initDesc.HeightRatio * Time::Get()->Delta();
				}
			}

			if (direction == 2 || direction == 3)
			{
				float dzi = z;
				float dz = (float)zi - dzi;
				float dy = (heightColors[index] * 255.0f / initDesc.HeightRatio) - GetHeight(position);
				float dist = sqrt(dz * dz + dy * dy);

				if (Mouse::Get()->Press(0))
				{
					if (Keyboard::Get()->Press(VK_LSHIFT))
						heightColors[index] -= power * dist / 255.0f * initDesc.HeightRatio * Time::Get()->Delta();
					else
						heightColors[index] += power * dist / 255.0f * initDesc.HeightRatio * Time::Get()->Delta();
				}
			}
		}
	}

	TextureApply();
}

void TerrainLod::TextureApply()
{
	ID3D11Texture2D* texture = heightMap->GetWritingTexture();

	D3D11_MAPPED_SUBRESOURCE subResource;
	D3D::GetDC()->Map(texture, 0, D3D11_MAP_WRITE, NULL, &subResource);
	{
		memcpy(subResource.pData, heightColors, sizeof(float) * width * height);
	}
	D3D::GetDC()->Unmap(texture, 0);

	heightMap->ChangeSRVTexture(DXGI_FORMAT_R32_FLOAT, texture);
	sHeightMap->SetResource(heightMap->SRV());
}

void TerrainLod::Splatting()
{
	static bool setLayer[4]{false};
	std::wstring file;
	//ImGui::InputInt("")
	shader->AsScalar("SetLayer")->SetBoolArray(setLayer, 0, 4);
	if (ImGui::Button("BaseLayer"))
	{
		Path::OpenFileDialog(file, Path::ImageFilter, L"../../_Textures/Terrain", [=](std::wstring path)
		{
			string folder = String::ToString(L"../../_Textures/Terrain");
			wstring files = path;
			if (files != L"")
			{
				setLayer[0] = true;
			}
			BaseMap(files);
		});
	}
	if (ImGui::Button("Layer1"))
	{
		Path::OpenFileDialog(file, Path::ImageFilter, L"../../_Textures/Terrain", [=](std::wstring path)
		{
			string folder = String::ToString(L"../../_Textures/Terrain");
			wstring files = path;
			if (files != L"")
			{
				setLayer[1] = true;
			}
			LayerMap1(files, L"Terrain/Alpha512.png");
		});
	}
	if (ImGui::Button("Layer2"))
	{
		Path::OpenFileDialog(file, Path::ImageFilter, L"../../_Textures/Terrain", [=](std::wstring path)
		{
			string folder = String::ToString(L"../../_Textures/Terrain");
			wstring files = path;
			if (files != L"")
			{
				setLayer[2] = true;
			}
			LayerMap2(files, L"Terrain/Alpha512.png");
		});
	}
	if (ImGui::Button("Layer3"))
	{
		Path::OpenFileDialog(file, Path::ImageFilter, L"../../_Textures/Terrain", [=](std::wstring path)
		{
			string folder = String::ToString(L"../../_Textures/Terrain");
			wstring files = path;
			if (files != L"")
			{
				setLayer[3] = true;
			}
			LayerMap3(files, L"Terrain/Alpha512.png");
		});
	}
}

